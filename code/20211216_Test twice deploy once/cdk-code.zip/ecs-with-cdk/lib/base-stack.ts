import core = require('@aws-cdk/core');
import * as ecr from '@aws-cdk/aws-ecr';
import * as ecs from '@aws-cdk/aws-ecs';
import { ApplicationLoadBalancedFargateService } from "@aws-cdk/aws-ecs-patterns";



export class BaseStack extends core.Stack {
  constructor(scope: core.Construct, id: string, props?: core.StackProps) {
    super(scope, id, props);


    const repository = new ecr.Repository(this, 'test-repository', {
      repositoryName: `te`
    });

    const albfs = new ApplicationLoadBalancedFargateService(this, 'test-fargate-test', {
      taskImageOptions: {
        image: ecs.ContainerImage.fromEcrRepository(repository, 'latest')
      }
    })

    albfs.targetGroup.configureHealthCheck({
      path: '/ator/health',
    });

  }
}
